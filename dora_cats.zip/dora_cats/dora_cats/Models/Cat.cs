﻿using System;
namespace dora_cats.Models
{
	public class Cat
	{
		public string url { get; set; }
		public string type { get; set; }
		public Cat(string url, string type = "image")
		{
			this.url = url;
			this.type = type;
		}
	}
}

