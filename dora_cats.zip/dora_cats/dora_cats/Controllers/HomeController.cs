﻿using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using dora_cats.Models;
using static System.Net.WebRequestMethods;

namespace dora_cats.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    List<Cat> kotiki = new List<Cat>()
    {
        new Cat(url: "https://media.tenor.com/zrpyKEyxZGwAAAAM/fat-cat-laser-eyes.gif", type:"gif"),
        new Cat(url: "https://i.pinimg.com/originals/d9/df/92/d9df9239a488ae9f2f5efd5f0b56af5e.gif", type:"gif"),
        new Cat(url: "https://thumbs.gfycat.com/VibrantAdorableHare-max-1mb.gif", type:"gif"),
        new Cat(url: "https://media.tenor.com/fTTVgygGDh8AAAAM/kitty-cat-sandwich.gif\n", type:"gif"),
        new Cat(url: "https://media2.giphy.com/media/cfuL5gqFDreXxkWQ4o/giphy.gif", type:"gif"),
        new Cat(url: "https://i.pinimg.com/originals/9a/3c/3f/9a3c3fb5f73822af8514df07f6676392.gif", type:"gif"),
        new Cat(url: "https://www.autostraddle.com/wp-content/uploads/2010/12/stoned-cats-gif.gif?resize=500%2C500", type:"gif"),
        new Cat(url: "https://media.tenor.com/7r-BGEoIohkAAAAM/meme-cat.gif", type:"gif"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIKwx5AvfTCbPczK4HRdqmhD2A2XnYa42meg&usqp=CAU", type:"gif"),
        new Cat(url: "https://usagif.com/wp-content/uploads/gify/dancing-cat-33-title.gif", type:"gif"),
        new Cat(url: "https://media.tenor.com/KVXBYKd3YZAAAAAd/cat-dance.gif", type:"gif"),
        new Cat(url: "https://techcrunch.com/wp-content/uploads/2013/03/falling_20cat.gif?w=430&h=230&crop=1", type:"gif"),
        new Cat(url: "https://media.glamour.com/photos/580e1fc08bd9950546d001f6/master/w_330,h_312,c_limit/giphy%20(11).gif", type:"gif"),
        new Cat(url: "https://cs9.pikabu.ru/post_img/big/2017/01/25/6/1485331254192128001.jpg", type:"image"),

        new Cat(url: "https://images.unsplash.com/photo-1608848461950-0fe51dfc41cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8M3x8fGVufDB8fHx8&w=1000&q=80", type:"image"),
        new Cat(url: "https://t4.ftcdn.net/jpg/00/97/58/97/360_F_97589769_t45CqXyzjz0KXwoBZT9PRaWGHRk5hQqQ.jpg", type:"image"),
        new Cat(url: "https://media.istockphoto.com/id/1361394182/photo/funny-british-shorthair-cat-portrait-looking-shocked-or-surprised.jpg?s=612x612&w=0&k=20&c=6yvVxdufrNvkmc50nCLCd8OFGhoJd6vPTNotl90L-vo=", type:"image"),
        new Cat(url: "https://t3.ftcdn.net/jpg/03/31/21/08/360_F_331210846_9yjYz8hRqqvezWIIIcr1sL8UB4zyhyQg.jpg", type:"image"),
        new Cat(url: "https://hips.hearstapps.com/hmg-prod/images/cute-cat-photos-1593441022.jpg?crop=1.00xw:0.753xh;0,0.153xh&resize=1200:*", type:"image"),
        new Cat(url: "https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fcf-images.us-east-1.prod.boltdns.net%2Fv1%2Fstatic%2F6157254766001%2F961ad642-68ec-4156-ab18-5fb26db7e85c%2Fa7fd44aa-762e-4be4-a99f-bdebcce91235%2F1280x720%2Fmatch%2Fimage.jpg", type:"image"),
        new Cat(url: "https://media.istockphoto.com/id/1322123064/photo/portrait-of-an-adorable-white-cat-in-sunglasses-and-an-shirt-lies-on-a-fabric-hammock.jpg?s=612x612&w=0&k=20&c=-G6l2c4jNI0y4cenh-t3qxvIQzVCOqOYZNvrRA7ZU5o=", type:"image"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvXpsm4RSo0WUNpbs_GPjBlwiv3QYb6OYnfA&usqp=CAU", type:"image"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSm8ErlMlPdnS5zbhJ2KL339H-cCsjrxjMl8A&usqp=CAU", type:"image"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiIViHG3NjHGW0bkB7nNGpxYIVZOrnNSI51g&usqp=CAU", type:"image"),
        new Cat(url: "https://cdn.shopify.com/s/files/1/1832/0821/files/catshark.jpg?v=1649869148", type:"image"),
        new Cat(url: "https://hips.hearstapps.com/hmg-prod/images/domestic-cat-lies-in-a-basket-with-a-knitted-royalty-free-image-1592337336.jpg?crop=0.88889xw:1xh;center,top&resize=1200:*", type:"image"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbWfpUmLzu2agjJjMGIa_Azfr4pyZZg8juAw&usqp=CAU", type:"image"),
        new Cat(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSth3MWZU2BB7e-4-DJ93clAmOppCpVfaSvtg&usqp=CAU", type:"image"),
    };

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }


    public IActionResult Index()
    {
        List<Cat> filter_gif_kotiki = kotiki.FindAll(kotik => kotik.type == "image");
        Cat random_kotik = filter_gif_kotiki[new Random().Next(0, filter_gif_kotiki.Count)];
        StreamWriter streamWriter = new StreamWriter("./logs.txt",true);
        streamWriter.WriteLine("Request image (" + DateTime.Now + ") | Response - " + random_kotik.url);
        streamWriter.Close();
        return View(random_kotik);
    }

    public IActionResult Gif()
    {
        List<Cat> filter_gif_kotiki = kotiki.FindAll(kotik => kotik.type == "gif");
        Cat random_kotik = filter_gif_kotiki[new Random().Next(0, filter_gif_kotiki.Count)];
        StreamWriter streamWriter = new StreamWriter("./logs.txt", true);
        streamWriter.WriteLine("Request GIF (" + DateTime.Now + ") | Response - " + random_kotik.url);
        streamWriter.Close();
        return View(random_kotik);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

